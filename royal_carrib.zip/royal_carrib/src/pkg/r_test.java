package pkg;

import org.testng.Assert;
import org.testng.annotations.Test;

public class r_test extends javacls {
	
  @Test
  public void f() throws InterruptedException {
	  
	  cruise();
	  
	  String act_res=royal_suite;
	  System.out.println(act_res);
	  Assert.assertTrue(act_res.contains("Royal Suite"));
	  System.out.println(b);
	  Assert.assertTrue(b);
  }
  
}
