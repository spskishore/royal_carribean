package pkg;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;




public class javacls {

	
	static String royal_suite;
	static boolean b;
	
	public void cruise() throws InterruptedException
	{
		
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		WebDriver  dr = new ChromeDriver();
		dr.get("https://www.royalcaribbean.com/alaska-cruises");
		dr.manage().window().maximize();
		dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		 b=dr.findElement(By.xpath("//div[@id='textWithUI-262899300']/div/div/a")).isDisplayed();
	
		dr.findElement(By.xpath("//a[@id='rciHeaderMenuItem-2']")).click();//search by ships
		Thread.sleep(3000);
	
		dr.findElement(By.xpath("//a[@href='/cruise-ships/rhapsody-of-the-seas']")).click(); //rhapsody of the seas
		Thread.sleep(7000);

		dr.findElement(By.xpath("//div[@class='filterSetDestination__container']/div[3]/a")).click();//dec plans
		Thread.sleep(3000);
	
		WebElement we=dr.findElement(By.id("deckDropdown"));
		Select sel=new Select(we);
	    sel.selectByVisibleText("Deck Eight");
	   // Thread.sleep(3000);
	    
	    
   royal_suite=dr.findElement(By.xpath("//div[@id=\"deck-plans-template\"]/section/section[2]/section[1]/div[2]/section[5]/h4")).getText();
		
		
	}
}
